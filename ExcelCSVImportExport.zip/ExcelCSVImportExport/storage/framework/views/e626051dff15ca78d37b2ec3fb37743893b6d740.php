<!DOCTYPE html>
<html>
<head>
  <title>Export to excel</title>
 
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
 
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
 
</head>
<body>
 
<div class="container mt-5">
 
   
  <?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
  <?php endif; ?>
 
  <div class="card">
 
    <div class="card-header font-weight-bold">
      <h2 class="float-left">Send mail with attachment file</h2>
      <h2 class="float-right"><a href="<?php echo e(url('export-excel-csv-file/xlsx')); ?>" class="btn btn-success mr-1">Export Excel</a><a href="<?php echo e(url('export-excel-csv-file/csv')); ?>" class="btn btn-success">Export CSV</a></h2>
    </div>
 
    <div class="card-body">
 
        <form id="excel-csv-import-form" method="POST"  action="<?php echo e(route('import-excel-csv.file')); ?>" accept-charset="utf-8" enctype="multipart/form-data">
 
          <?php echo csrf_field(); ?>
                   
            <div class="row">
 
                <div class="col-md-12">
                    <label for="email">Put email id</label>
                    <div class="form-group">
                        <input type="email" class="form-control" name="email" placeholder="put email id">
                    </div>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>   
                <div class="form-group">
                    <label for="exampleFormControlTextarea1">Message</label>
                    <textarea class="form-control" name="message" id="exampleFormControlTextarea1" rows="3"></textarea>
                </div>           
                <div class="col-md-12">
                    <div class="form-group">
                        <input type="file" name="document" placeholder="Choose file">
                    </div>
                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>              
  
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary" id="submit">Submit</button>
                </div>
            </div>     
        </form>
 
    </div>
 
  </div>
 
</div>  
</body>
</html><?php /**PATH C:\xampp\htdocs\project\ExcelCSVImportExport\resources\views\excel-csv-import.blade.php ENDPATH**/ ?>