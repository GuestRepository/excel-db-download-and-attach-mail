
Hello <b> <?php echo e($exportExcelFile['message']); ?></b>,



</p>
Thank You,
<br/>
<i>cashand Team</i>

<?php /**PATH C:\xampp\htdocs\project\ExcelCSVImportExport\resources\views\excelfilemail\send_excel_file_mail.blade.php ENDPATH**/ ?>