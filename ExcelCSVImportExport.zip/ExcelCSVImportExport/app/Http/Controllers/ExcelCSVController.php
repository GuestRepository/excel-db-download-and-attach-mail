<?php
 
namespace App\Http\Controllers;
 
use Log;
use App\Models\User;
use App\Exports\UsersExport;
use App\Imports\UsersImport;
use Illuminate\Http\Request;
use Illuminate\Mail\Mailable;
use App\Mail\SendExcelFileEmail;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\LaravelNovaExcel\Actions\DownloadExcel;
 
class ExcelCSVController extends Controller
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function index()
    {
       return view('excel-csv-import');
    }
    
    /**
    * @return \Illuminate\Support\Collection
    */
  
 
    /**
    * @return \Illuminate\Support\Collection
    */
    public function exportExcelCSV($slug) 
    {
        $unix_timestamp = now()->timestamp;
        $randomKey = rand(1,10).$unix_timestamp;
        $donwloadExcel =  Excel::store(new UsersExport, $randomKey.'.'.$slug);
        $donwloadFileExcel = $randomKey.'.'.$slug;
        return redirect()->route('send-excel-file-email', ['slug' => $randomKey]);
    }

 
    public function gettingexcel($slug){
        $allUser = User::all();
        return view('send-excel-file-email', compact('slug','allUser'));
    }


    public function mailExportExcelCSV(Request $request) 
    {
        $validatedData = $request->validate([
           'email' => 'required',
           'document' => 'required',
        ]);
        $file = $request->document;
        $getFile = $file.'.xlsx';
        Log::info('file ka naam '.$getFile);
        $exportExcelFile = array(
            'email' => $request->email,
            'message' => $request->message,
            'document' => storage_path('app/'.$getFile),
        );
        Mail::to($exportExcelFile['email'])->send(new SendExcelFileEmail($exportExcelFile));
        $excelFileUnlink = unlink(storage_path('app/'.$getFile));
        Log::info('file has been delete '.$getFile);
        return redirect('excel-csv-file')->with('status', 'The file has been excel/csv file has been sent to your email');
    }


  

   
}