<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SendExcelFileEmail extends Mailable
{
    use Queueable, SerializesModels;
    public $exportExcelFile;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($exportExcelFile)
    {
        $this->exportExcelFile = $exportExcelFile;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from('info@cashand.com')
        ->subject('Excel File send by cashand team')
        ->view('excelfilemail.send_excel_file_mail')
        ->with('data', $this->exportExcelFile)
        ->attach($this->exportExcelFile['document']);
    }
}
